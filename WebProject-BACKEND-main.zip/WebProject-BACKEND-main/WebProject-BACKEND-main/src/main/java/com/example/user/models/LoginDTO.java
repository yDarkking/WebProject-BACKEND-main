package com.example.user.models;

public record LoginDTO(String email, String password) {
    
}
