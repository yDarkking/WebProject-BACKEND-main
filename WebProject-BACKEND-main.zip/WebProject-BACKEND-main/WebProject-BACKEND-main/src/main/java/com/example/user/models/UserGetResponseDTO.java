package com.example.user.models;

public record UserGetResponseDTO(String nome, int idade) {
    
}
